#ifndef _IMPLICITMIDPOINTEQUATIONSOLVER_
#define _IMPLICITMIDPOINTEQUATIONSOLVER_

#include "EquationSolver.h"

class ImplicitMidpointEquationSolver: public EquationSolver {
  
public:
  double FindSolution(double f(double, double), double yn, double xn, double h, double start, double stop, double tol=1.0E-3);
  
protected:
  virtual double fzero(double x);
  
  double _yn;
  double _xn;
  double _h;
  double (*_f)(double, double);
};

#endif
