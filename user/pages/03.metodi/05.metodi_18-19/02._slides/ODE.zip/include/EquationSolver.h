#ifndef _EQUATIONSOLVER_
#define _EQUATIONSOLVER_

class EquationSolver {
  
public:
  double FindSolution(double f(double), double lhs, double start, double stop, double tol=1.0E-3);
  
protected:
  virtual double fzero(double x);
  double bisez(double a, double b, double tol=1.0E-3);

  double _lhs;
  double (*_f)(double);
};

#endif
